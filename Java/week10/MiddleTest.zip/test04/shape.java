public abstract class shape {
    public double x;
    public double y;
    public abstract double area();
}
