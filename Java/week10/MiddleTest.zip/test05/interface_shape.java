public interface interface_shape {
    public void area();
}
