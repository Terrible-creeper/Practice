public abstract class show_shape {
    abstract void show();
}
